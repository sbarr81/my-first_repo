print("Hello, world!")
print("This is my first GitHub respository.")
print("This repository will help me learn how to use GitHub!")