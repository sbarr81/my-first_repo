# Python Coding Resources

* [About Python on Python.org](https://www.python.org/): an overview of the Python programming language

* [Try It: Intro to Python on edX](https://www.edx.org/course/intro-python): a course that covers the basics of Python coding

* [Replit](https://replit.com/languages/python3): an online code editor that can be used to run Python code without installing anything on a computer